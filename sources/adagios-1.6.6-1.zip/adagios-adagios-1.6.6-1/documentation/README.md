This directory was created to hold images for https://github.com/opinkerfi/adagios/wiki
