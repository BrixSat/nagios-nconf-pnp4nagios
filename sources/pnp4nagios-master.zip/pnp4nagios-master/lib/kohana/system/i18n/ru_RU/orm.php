<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang['query_methods_not_allowed'] = 'Методы запросов не могут быть использованы через ORM';
