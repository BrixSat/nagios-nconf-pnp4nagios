<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'undefined_group'   => 'The %s group is not defined in your configuration.',
	'requires_mcrypt'   => 'To use the Encrypt library, mcrypt must be enabled in your PHP installation',
	'no_encryption_key' => 'To use the Encrypt library, you must set an encryption key in your config file'
);
