<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'undefined_group'      => 'Die Gruppe %s ist in Ihrer Konfiguration nicht definiert.',
	'extension_not_loaded' => 'Die PHP-Erweiterung %s muss geladen sein, um diesen Treiber benutzen zu können.',
	'unwritable'           => 'Der eingestellte Speicherort %s ist nicht beschreibbar.',
	'resources'            => 'Das Cachen von Ressourcen ist nicht möglich, da diese nicht serialisiert werden können.',
	'driver_error'         => '%s'
);