<!-- Widget Menu Start -->
<div class="ui-widget">
<div class="p2 ui-widget-header ui-corner-top">
Title
</div>
<div class="p4 ui-widget-content ui-corner-bottom" >
Content
</div>
</div><p>
<!-- Widget Menu End -->
