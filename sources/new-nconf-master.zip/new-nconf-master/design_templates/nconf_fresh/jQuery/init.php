<?php
### defines some jquery related stuff for nconf
# enable jquery
define('JQUERY', '1');

# jquery theme
define('JQUERY_THEME', 'nconf');

# enable jquery theme switcher
define('JQUERY_THEME_SWITCHER', '0');
?>
