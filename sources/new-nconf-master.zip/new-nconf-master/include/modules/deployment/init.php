<?php
##
## Deployment module
##
define('ALLOW_DIRECT_DEPLOYMENT', 0);

?>
